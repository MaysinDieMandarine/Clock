﻿
namespace Wecker_1._0
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.anwendungToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.beendenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stellen_Button = new System.Windows.Forms.Button();
            this.stop_Button = new System.Windows.Forms.Button();
            this.displayPanel = new System.Windows.Forms.Panel();
            this.message_label = new System.Windows.Forms.Label();
            this.static_clocklabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.minutes_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.hours_numericUpDown = new System.Windows.Forms.NumericUpDown();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.melodie1_raidoButton = new System.Windows.Forms.RadioButton();
            this.melodie1_radioButton = new System.Windows.Forms.RadioButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.menuStrip1.SuspendLayout();
            this.displayPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.minutes_numericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hours_numericUpDown)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.anwendungToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(509, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // anwendungToolStripMenuItem
            // 
            this.anwendungToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.programmToolStripMenuItem});
            this.anwendungToolStripMenuItem.Name = "anwendungToolStripMenuItem";
            this.anwendungToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
            this.anwendungToolStripMenuItem.Text = "Anwendung";
            // 
            // programmToolStripMenuItem
            // 
            this.programmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.beendenToolStripMenuItem});
            this.programmToolStripMenuItem.Name = "programmToolStripMenuItem";
            this.programmToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.programmToolStripMenuItem.Text = "Programm";
            // 
            // beendenToolStripMenuItem
            // 
            this.beendenToolStripMenuItem.Name = "beendenToolStripMenuItem";
            this.beendenToolStripMenuItem.ShowShortcutKeys = false;
            this.beendenToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.beendenToolStripMenuItem.Text = "Beenden";
            this.beendenToolStripMenuItem.Click += new System.EventHandler(this.beendenToolStripMenuItem_Click);
            // 
            // stellen_Button
            // 
            this.stellen_Button.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.stellen_Button.Location = new System.Drawing.Point(245, 191);
            this.stellen_Button.Name = "stellen_Button";
            this.stellen_Button.Size = new System.Drawing.Size(75, 23);
            this.stellen_Button.TabIndex = 5;
            this.stellen_Button.Text = "Setzen";
            this.stellen_Button.UseVisualStyleBackColor = false;
            this.stellen_Button.Click += new System.EventHandler(this.stellen_Button_Click);
            // 
            // stop_Button
            // 
            this.stop_Button.BackColor = System.Drawing.Color.Red;
            this.stop_Button.Location = new System.Drawing.Point(336, 191);
            this.stop_Button.Name = "stop_Button";
            this.stop_Button.Size = new System.Drawing.Size(75, 23);
            this.stop_Button.TabIndex = 6;
            this.stop_Button.Text = "Stop";
            this.stop_Button.UseVisualStyleBackColor = false;
            this.stop_Button.Click += new System.EventHandler(this.stop_Button_Click);
            // 
            // displayPanel
            // 
            this.displayPanel.BackColor = System.Drawing.Color.Black;
            this.displayPanel.Controls.Add(this.message_label);
            this.displayPanel.Controls.Add(this.static_clocklabel);
            this.displayPanel.Location = new System.Drawing.Point(12, 28);
            this.displayPanel.Name = "displayPanel";
            this.displayPanel.Size = new System.Drawing.Size(497, 42);
            this.displayPanel.TabIndex = 8;
            // 
            // message_label
            // 
            this.message_label.AutoSize = true;
            this.message_label.Font = new System.Drawing.Font("Microsoft YaHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.message_label.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.message_label.Location = new System.Drawing.Point(259, 3);
            this.message_label.Name = "message_label";
            this.message_label.Size = new System.Drawing.Size(162, 35);
            this.message_label.TabIndex = 1;
            this.message_label.Text = "ClockLabel";
            // 
            // static_clocklabel
            // 
            this.static_clocklabel.AutoSize = true;
            this.static_clocklabel.Font = new System.Drawing.Font("Microsoft YaHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.static_clocklabel.ForeColor = System.Drawing.SystemColors.Control;
            this.static_clocklabel.Location = new System.Drawing.Point(18, 3);
            this.static_clocklabel.Name = "static_clocklabel";
            this.static_clocklabel.Size = new System.Drawing.Size(68, 35);
            this.static_clocklabel.TabIndex = 0;
            this.static_clocklabel.Text = "Zeit";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.minutes_numericUpDown);
            this.panel1.Controls.Add(this.hours_numericUpDown);
            this.panel1.Location = new System.Drawing.Point(231, 76);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 100);
            this.panel1.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Uhrzeit";
            // 
            // minutes_numericUpDown
            // 
            this.minutes_numericUpDown.BackColor = System.Drawing.SystemColors.Window;
            this.minutes_numericUpDown.Location = new System.Drawing.Point(4, 58);
            this.minutes_numericUpDown.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.minutes_numericUpDown.Name = "minutes_numericUpDown";
            this.minutes_numericUpDown.Size = new System.Drawing.Size(120, 20);
            this.minutes_numericUpDown.TabIndex = 1;
            // 
            // hours_numericUpDown
            // 
            this.hours_numericUpDown.Location = new System.Drawing.Point(4, 19);
            this.hours_numericUpDown.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.hours_numericUpDown.Name = "hours_numericUpDown";
            this.hours_numericUpDown.Size = new System.Drawing.Size(120, 20);
            this.hours_numericUpDown.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.melodie1_raidoButton);
            this.panel2.Controls.Add(this.melodie1_radioButton);
            this.panel2.Location = new System.Drawing.Point(29, 119);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 85);
            this.panel2.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Melodie";
            // 
            // melodie1_raidoButton
            // 
            this.melodie1_raidoButton.AutoSize = true;
            this.melodie1_raidoButton.Location = new System.Drawing.Point(4, 50);
            this.melodie1_raidoButton.Name = "melodie1_raidoButton";
            this.melodie1_raidoButton.Size = new System.Drawing.Size(105, 17);
            this.melodie1_raidoButton.TabIndex = 1;
            this.melodie1_raidoButton.TabStop = true;
            this.melodie1_raidoButton.Text = "Over the Horizon";
            this.melodie1_raidoButton.UseVisualStyleBackColor = true;
            // 
            // melodie1_radioButton
            // 
            this.melodie1_radioButton.AutoSize = true;
            this.melodie1_radioButton.Location = new System.Drawing.Point(4, 16);
            this.melodie1_radioButton.Name = "melodie1_radioButton";
            this.melodie1_radioButton.Size = new System.Drawing.Size(62, 17);
            this.melodie1_radioButton.TabIndex = 0;
            this.melodie1_radioButton.TabStop = true;
            this.melodie1_radioButton.Text = "Kalimba";
            this.melodie1_radioButton.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(29, 76);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(509, 244);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.displayPanel);
            this.Controls.Add(this.stop_Button);
            this.Controls.Add(this.stellen_Button);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Wecker";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.displayPanel.ResumeLayout(false);
            this.displayPanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.minutes_numericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hours_numericUpDown)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem anwendungToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem beendenToolStripMenuItem;
        private System.Windows.Forms.Button stellen_Button;
        private System.Windows.Forms.Button stop_Button;
        private System.Windows.Forms.Panel displayPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown minutes_numericUpDown;
        private System.Windows.Forms.NumericUpDown hours_numericUpDown;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton melodie1_raidoButton;
        private System.Windows.Forms.RadioButton melodie1_radioButton;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label message_label;
        private System.Windows.Forms.Label static_clocklabel;
    }
}

