﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace Wecker_1._0
{
    public partial class Form1 : Form
    {
        static SoundPlayer sound1 = new SoundPlayer(@"C:\Windows\Media\tada.wav");
        static SoundPlayer sound2 = new SoundPlayer(@"C:\Windows\Media\ir_inter.wav");
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void stellen_Button_Click(object sender, EventArgs e)
        {
            DateTime dt = new DateTime(dateTimePicker1.Value.Year,
                dateTimePicker1.Value.Month,
                dateTimePicker1.Value.Day,
                Convert.ToInt32(hours_numericUpDown.Value),
                Convert.ToInt32(minutes_numericUpDown.Value),
                Convert.ToInt32(DateTime.Now.Second));
            if(dt <= DateTime.Now)
            {
                MessageBox.Show("Willst du in der Vergangenheit geweckt werden?");
            }
            else
            {
                clockTimer.Interval = 1000;
                clockTimer.Tick += new EventHandler(clockTimerCheck);
                clockTimer.Start();
            }
        }

        private void clockTimerCheck(object sender, EventArgs e)
        {
            string systemzeit = Convert.ToString(DateTime.Now.Hour
                + ":" + DateTime.Now.Minute);
            string weckzeit = Convert.ToString(hours_numericUpDown.Value 
                + ":" +
                minutes_numericUpDown.Value);
            message_label.Text = "Weckzeit:" + weckzeit;
            if(systemzeit == weckzeit) 
            {
                message_label.Text = "AUFWACHEN";
                if (melodie1_radioButton.Checked)
                {
                    sound1.PlayLooping();
                }
                else 
                {
                    sound2.PlayLooping();
                }
            }
        }

        private void beendenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        static Timer static_clockTimer = new Timer();
        static Timer clockTimer = new Timer();
        private void Form1_Load(object sender, EventArgs e)
        {
            static_clockTimer.Interval = 1000;
            static_clockTimer.Tick += new EventHandler(Static_clockTimer_Tick);
            static_clockTimer.Start();
        }

        private void Static_clockTimer_Tick(object sender, EventArgs e)
        {

            string dtime = Convert.ToString
                (DateTime.Now.Hour +
                ":" + DateTime.Now.Minute + ":" +
                DateTime.Now.Second);
            static_clocklabel.Text = dtime;
        }

        private void stop_Button_Click(object sender, EventArgs e)
        {
            message_label.Text = "";
            clockTimer.Stop();
            if (melodie1_radioButton.Checked)
            {
                sound1.Stop();
            }
            else
            {
                sound2.Stop();
            }
        }
    }
}
